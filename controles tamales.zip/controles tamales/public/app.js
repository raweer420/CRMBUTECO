﻿const state = {
  units: [],
  bills: [],
  filters: {
    q: "",
    status: "all",
    category: "all",
    month: "",
    sort: "due_asc",
  },
  editingBill: null,
};

const currencyFmt = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const els = {
  billsTbody: document.querySelector("#bills-tbody"),
  totalPending: document.querySelector("#total-pending"),
  totalPaid: document.querySelector("#total-paid"),
  totalMonth: document.querySelector("#total-month"),
  totalMonthLabel: document.querySelector("#total-month-label"),
  unitTotals: document.querySelector("#unit-totals"),
  filterSearch: document.querySelector("#filter-search"),
  filterStatus: document.querySelector("#filter-status"),
  filterCategory: document.querySelector("#filter-category"),
  filterMonth: document.querySelector("#filter-month"),
  filterSort: document.querySelector("#filter-sort"),
  btnClearFilters: document.querySelector("#btn-clear-filters"),
  btnNew: document.querySelector("#btn-new"),
  btnExportCsv: document.querySelector("#btn-export-csv"),
  btnBackup: document.querySelector("#btn-backup"),
  toast: document.querySelector("#toast"),

  billDialog: document.querySelector("#bill-dialog"),
  billDialogTitle: document.querySelector("#bill-dialog-title"),
  btnCloseDialog: document.querySelector("#btn-close-dialog"),
  btnCancelForm: document.querySelector("#btn-cancel-form"),
  billForm: document.querySelector("#bill-form"),
  fileInput: document.querySelector("#file-input"),

  sharedCheckbox: document.querySelector("#shared-checkbox"),
  splitModeWrap: document.querySelector("#split-mode-wrap"),
  splitModeSelect: document.querySelector("#split-mode-select"),
  splitsSection: document.querySelector("#splits-section"),
  splitsBody: document.querySelector("#splits-body"),
  splitHint: document.querySelector("#split-hint"),
  splitTotalFeedback: document.querySelector("#split-total-feedback"),

  primaryUnitSelect: document.querySelector("#primary-unit-select"),
  primaryUnitWrap: document.querySelector("#primary-unit-wrap"),

  existingFilesWrap: document.querySelector("#existing-files-wrap"),
  existingFilesList: document.querySelector("#existing-files-list"),

  filesDialog: document.querySelector("#files-dialog"),
  filesListWrap: document.querySelector("#files-list-wrap"),
  imagePreviewWrap: document.querySelector("#image-preview-wrap"),
  btnCloseFiles: document.querySelector("#btn-close-files"),
};

function formatMoney(value) {
  return currencyFmt.format(Number(value || 0));
}

function formatDate(value) {
  if (!value) return "-";
  const [year, month, day] = value.split("-");
  if (!year || !month || !day) return value;
  return `${day}/${month}/${year}`;
}

function formatMonth(value) {
  if (!value || value.length !== 7) return value || "-";
  const [year, month] = value.split("-");
  return `${month}/${year}`;
}

function bytesToHuman(bytes) {
  const num = Number(bytes || 0);
  if (num < 1024) return `${num} B`;
  if (num < 1024 * 1024) return `${(num / 1024).toFixed(1)} KB`;
  return `${(num / (1024 * 1024)).toFixed(1)} MB`;
}

function showToast(message, isError = false) {
  els.toast.textContent = message;
  els.toast.classList.remove("hidden");
  els.toast.style.background = isError ? "#8d1d1d" : "#12253d";

  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    els.toast.classList.add("hidden");
  }, 2800);
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  const contentType = response.headers.get("content-type") || "";

  let body = null;
  if (contentType.includes("application/json")) {
    body = await response.json();
  } else {
    body = await response.text();
  }

  if (!response.ok) {
    const message = typeof body === "object" && body ? body.error || "Erro na requisicao." : String(body);
    throw new Error(message);
  }

  return body;
}

function debounce(fn, delayMs) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delayMs);
  };
}

function monthNow() {
  return new Date().toISOString().slice(0, 7);
}

function dateNow() {
  return new Date().toISOString().slice(0, 10);
}

function toCents(value) {
  return Math.round(Number(value || 0) * 100);
}

function fromCents(cents) {
  return Number((cents / 100).toFixed(2));
}

function computeEqualSplit(totalAmount, count) {
  const totalCents = toCents(totalAmount);
  const base = Math.floor(totalCents / count);
  const remainder = totalCents - base * count;

  return Array.from({ length: count }).map((_, index) => {
    const cents = index === 0 ? base + remainder : base;
    return fromCents(cents);
  });
}

function splitRows() {
  return [...els.splitsBody.querySelectorAll("tr")];
}

function getSplitDataFromTable() {
  return splitRows().map((row) => {
    const unitId = Number(row.dataset.unitId);
    const amountInput = row.querySelector(".split-amount");
    const paidInput = row.querySelector(".split-paid");

    return {
      unit_id: unitId,
      amount: Number(amountInput.value || 0),
      paid: paidInput.checked,
      paid_at: paidInput.checked ? dateNow() : null,
    };
  });
}

function buildSplitRows(existingSplits = []) {
  const byUnit = new Map(existingSplits.map((split) => [Number(split.unit_id), split]));

  els.splitsBody.innerHTML = "";
  for (const unit of state.units) {
    const found = byUnit.get(unit.id);

    const tr = document.createElement("tr");
    tr.dataset.unitId = String(unit.id);
    tr.innerHTML = `
      <td>${unit.name}</td>
      <td>
        <input
          class="split-amount split-input"
          type="number"
          min="0"
          step="0.01"
          value="${Number(found?.amount || 0).toFixed(2)}"
        />
      </td>
      <td>
        <input class="split-paid" type="checkbox" ${found?.paid ? "checked" : ""} />
      </td>
    `;

    els.splitsBody.appendChild(tr);
  }

  updateSplitModeUI();
}

function updateSplitModeUI() {
  const shared = els.sharedCheckbox.checked;
  const splitMode = els.splitModeSelect.value;

  els.splitModeWrap.classList.toggle("hidden", !shared);
  els.splitsSection.classList.toggle("hidden", !shared);
  els.primaryUnitWrap.classList.toggle("hidden", shared);

  if (!shared) {
    return;
  }

  const totalAmount = Number(els.billForm.elements.total_amount.value || 0);

  if (splitMode === "equal") {
    const equal = computeEqualSplit(totalAmount, state.units.length);
    splitRows().forEach((row, idx) => {
      const amountInput = row.querySelector(".split-amount");
      amountInput.value = equal[idx].toFixed(2);
      amountInput.readOnly = true;
    });
    els.splitHint.textContent = "Divisao igualitaria em 4 partes. Centavos residuais ficam na primeira unidade.";
    els.splitTotalFeedback.textContent = `Total da divisao: ${formatMoney(totalAmount)}`;
    els.splitTotalFeedback.style.color = "#596579";
  } else {
    splitRows().forEach((row) => {
      const amountInput = row.querySelector(".split-amount");
      amountInput.readOnly = false;
    });

    const splits = getSplitDataFromTable();
    const splitTotal = splits.reduce((sum, split) => sum + toCents(split.amount), 0);
    const totalCents = toCents(totalAmount);

    if (splitTotal === totalCents) {
      els.splitTotalFeedback.textContent = `Total da divisao confere: ${formatMoney(fromCents(splitTotal))}`;
      els.splitTotalFeedback.style.color = "#197845";
    } else {
      const diff = fromCents(totalCents - splitTotal);
      els.splitTotalFeedback.textContent = `Diferenca de ${formatMoney(diff)} entre total da conta e soma das partes.`;
      els.splitTotalFeedback.style.color = "#b9312f";
    }

    els.splitHint.textContent = "Modo custom: ajuste manualmente o valor de cada unidade.";
  }
}

function divisionLabel(bill) {
  if (!bill.shared) {
    if (bill.primary_unit_name) {
      return `Nao (resp: ${bill.primary_unit_name})`;
    }
    return "Nao";
  }

  if (bill.split_mode === "equal") {
    if (Array.isArray(bill.splits) && bill.splits.length === state.units.length) {
      const amounts = bill.splits.map((split) => Number(split.amount || 0));
      const unique = [...new Set(amounts.map((value) => value.toFixed(2)))];

      if (unique.length === 1) {
        return `${formatMoney(amounts[0])} cada`;
      }

      const min = Math.min(...amounts);
      const max = Math.max(...amounts);
      if (toCents(max - min) <= 3) {
        return `${formatMoney(min)} cada (+ajuste centavos na 1a)`;
      }
    }

    const each = Number(bill.total_amount || 0) / state.units.length;
    return `${formatMoney(each)} cada`;
  }

  return "Custom";
}

function renderBills() {
  if (!state.bills.length) {
    els.billsTbody.innerHTML = `
      <tr>
        <td class="empty" colspan="10">Nenhuma conta encontrada para os filtros.</td>
      </tr>
    `;
    return;
  }

  els.billsTbody.innerHTML = state.bills
    .map((bill) => {
      const badgeClass = bill.status === "paid" ? "paid" : "pending";
      const badgeText = bill.status === "paid" ? "Pago" : "Pendente";
      const toggleText = bill.status === "paid" ? "Voltar pendente" : "Marcar pago";

      return `
        <tr>
          <td><span class="badge ${badgeClass}">${badgeText}</span></td>
          <td title="${bill.title}">${bill.title}</td>
          <td>${bill.category}</td>
          <td>${formatMonth(bill.reference_month)}</td>
          <td>${formatDate(bill.due_date)}</td>
          <td>${formatMoney(bill.total_amount)}</td>
          <td>${bill.shared ? "Sim" : "Nao"}</td>
          <td>${divisionLabel(bill)}</td>
          <td>
            <button type="button" data-action="files" data-id="${bill.id}">
              Ver (${bill.files_count})
            </button>
          </td>
          <td>
            <div class="actions">
              <button type="button" data-action="edit" data-id="${bill.id}">Editar</button>
              <button type="button" data-action="toggle-status" data-id="${bill.id}" data-status="${bill.status}">${toggleText}</button>
              <button type="button" class="danger" data-action="delete" data-id="${bill.id}">Excluir</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");
}

function renderUnitTotals(perUnit) {
  els.unitTotals.innerHTML = "";
  for (const unit of perUnit) {
    const card = document.createElement("article");
    card.className = "unit-card";
    card.innerHTML = `
      <h4>${unit.name}</h4>
      <p>Total no mes: <strong>${formatMoney(unit.total_amount)}</strong></p>
      <p>Pendente: <strong>${formatMoney(unit.pending_amount)}</strong></p>
    `;
    els.unitTotals.appendChild(card);
  }
}

async function loadBills() {
  const params = new URLSearchParams();
  if (state.filters.q) params.set("q", state.filters.q);
  if (state.filters.status !== "all") params.set("status", state.filters.status);
  if (state.filters.category !== "all") params.set("category", state.filters.category);
  if (state.filters.month) params.set("month", state.filters.month);
  params.set("sort", state.filters.sort);

  const data = await api(`/api/bills?${params.toString()}`);
  state.bills = data.bills;
  renderBills();
}

async function loadDashboard() {
  const params = new URLSearchParams();
  if (state.filters.month) params.set("month", state.filters.month);

  const data = await api(`/api/dashboard?${params.toString()}`);
  els.totalPending.textContent = formatMoney(data.total_pending);
  els.totalPaid.textContent = formatMoney(data.total_paid);
  els.totalMonth.textContent = formatMoney(data.total_month);
  els.totalMonthLabel.textContent = `Mes: ${formatMonth(data.selected_month)}`;
  renderUnitTotals(data.per_unit);
}

async function refreshData() {
  await Promise.all([loadBills(), loadDashboard()]);
}

function resetFormToNew() {
  state.editingBill = null;
  els.billDialogTitle.textContent = "Nova conta";
  els.billForm.reset();

  els.billForm.elements.category.value = "luz";
  els.billForm.elements.reference_month.value = monthNow();
  els.billForm.elements.due_date.value = dateNow();
  els.billForm.elements.total_amount.value = "0.00";
  els.billForm.elements.notes.value = "";
  els.sharedCheckbox.checked = false;
  els.splitModeSelect.value = "equal";
  els.primaryUnitSelect.value = "";
  els.fileInput.value = "";

  els.existingFilesWrap.classList.add("hidden");
  els.existingFilesList.innerHTML = "";
  buildSplitRows([]);
}

function renderExistingFiles(files) {
  if (!files.length) {
    els.existingFilesWrap.classList.add("hidden");
    els.existingFilesList.innerHTML = "";
    return;
  }

  els.existingFilesWrap.classList.remove("hidden");
  els.existingFilesList.innerHTML = files
    .map(
      (file) => `
      <li class="file-row" data-file-id="${file.id}">
        <div>
          <strong>${file.original_name}</strong>
          <small>${bytesToHuman(file.size_bytes)}</small>
        </div>
        <div class="file-actions">
          <a href="${file.url}" target="_blank" rel="noopener">Abrir</a>
          <button type="button" class="danger" data-action="delete-existing-file" data-file-id="${file.id}">Remover</button>
        </div>
      </li>
    `
    )
    .join("");
}

async function openEditDialog(billId) {
  const data = await api(`/api/bills/${billId}`);
  fillFormFromBill(data.bill);
  els.billDialog.showModal();
}

function openNewDialog() {
  resetFormToNew();
  els.billDialog.showModal();
}

function closeBillDialog() {
  els.billDialog.close();
}

async function submitBillForm(event) {
  event.preventDefault();

  if (!els.billForm.reportValidity()) {
    return;
  }

  const totalAmount = Number(els.billForm.elements.total_amount.value || 0);
  if (totalAmount < 0) {
    showToast("Valor total deve ser maior ou igual a zero.", true);
    return;
  }

  const shared = els.sharedCheckbox.checked;
  const splitMode = els.splitModeSelect.value;

  const payload = {
    title: els.billForm.elements.title.value.trim(),
    category: els.billForm.elements.category.value,
    reference_month: els.billForm.elements.reference_month.value,
    due_date: els.billForm.elements.due_date.value,
    total_amount: Number(totalAmount.toFixed(2)),
    shared,
    split_mode: splitMode,
    notes: els.billForm.elements.notes.value.trim(),
    primary_unit_id: els.primaryUnitSelect.value || null,
  };

  if (state.editingBill) {
    payload.status = state.editingBill.status;
    payload.paid_at = state.editingBill.paid_at;
  }

  if (shared) {
    const splits = getSplitDataFromTable().map((split) => ({
      ...split,
      amount: Number(split.amount.toFixed(2)),
    }));

    if (splitMode === "custom") {
      const splitCents = splits.reduce((sum, split) => sum + toCents(split.amount), 0);
      const totalCents = toCents(totalAmount);
      if (splitCents !== totalCents) {
        showToast("No modo custom, a soma das partes deve bater com o valor total.", true);
        return;
      }
    }

    payload.splits = splits;
  }

  const formData = new FormData();
  formData.append("payload", JSON.stringify(payload));

  for (const file of els.fileInput.files) {
    formData.append("files", file);
  }

  const isEditing = Boolean(state.editingBill);
  const endpoint = isEditing ? `/api/bills/${state.editingBill.id}` : "/api/bills";
  const method = isEditing ? "PUT" : "POST";

  await api(endpoint, {
    method,
    body: formData,
  });

  closeBillDialog();
  await refreshData();
  showToast(isEditing ? "Conta atualizada." : "Conta criada.");
}

async function deleteBill(billId) {
  const shouldDelete = window.confirm("Deseja excluir esta conta? Isso remove splits e anexos do disco.");
  if (!shouldDelete) {
    return;
  }

  await api(`/api/bills/${billId}`, { method: "DELETE" });
  await refreshData();
  showToast("Conta excluida.");
}

async function toggleBillStatus(billId, currentStatus) {
  const nextStatus = currentStatus === "paid" ? "pending" : "paid";

  await api(`/api/bills/${billId}/status`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: nextStatus }),
  });

  await refreshData();
  showToast(nextStatus === "paid" ? "Conta marcada como paga." : "Conta voltou para pendente.");
}

async function openFilesDialog(billId) {
  const data = await api(`/api/bills/${billId}/files`);
  const files = data.files;

  if (!files.length) {
    els.filesListWrap.innerHTML = "<p>Nenhum anexo para esta conta.</p>";
    els.imagePreviewWrap.innerHTML = "";
    els.filesDialog.showModal();
    return;
  }

  els.filesListWrap.innerHTML = `
    <ul class="file-list">
      ${files
        .map(
          (file) => `
        <li class="file-row">
          <div>
            <strong>${file.original_name}</strong>
            <small>${bytesToHuman(file.size_bytes)}</small>
          </div>
          <div class="file-actions">
            <a href="${file.url}" target="_blank" rel="noopener">Abrir</a>
            <a href="${file.url}" download>Download</a>
          </div>
        </li>
      `
        )
        .join("")}
    </ul>
  `;

  const imageFiles = files.filter((file) => file.mime_type.startsWith("image/"));
  els.imagePreviewWrap.innerHTML = imageFiles
    .map((file) => `<img src="${file.url}" alt="${file.original_name}" />`)
    .join("");

  els.filesDialog.showModal();
}

async function deleteExistingFile(fileId) {
  const shouldDelete = window.confirm("Remover este anexo do disco?");
  if (!shouldDelete) return;

  await api(`/api/files/${fileId}`, { method: "DELETE" });

  if (state.editingBill) {
    const data = await api(`/api/bills/${state.editingBill.id}`);
    fillFormFromBill(data.bill);
  }

  await refreshData();
  showToast("Anexo removido.");
}

function fillFormFromBill(bill) {
  state.editingBill = bill;
  els.billDialogTitle.textContent = `Editar conta #${bill.id}`;

  els.billForm.elements.title.value = bill.title;
  els.billForm.elements.category.value = bill.category;
  els.billForm.elements.reference_month.value = bill.reference_month;
  els.billForm.elements.due_date.value = bill.due_date;
  els.billForm.elements.total_amount.value = Number(bill.total_amount).toFixed(2);
  els.billForm.elements.notes.value = bill.notes || "";
  els.sharedCheckbox.checked = !!bill.shared;
  els.splitModeSelect.value = bill.split_mode || "equal";
  els.primaryUnitSelect.value = bill.primary_unit_id ? String(bill.primary_unit_id) : "";
  els.fileInput.value = "";

  buildSplitRows(bill.splits || []);
  renderExistingFiles(bill.files || []);
}

function fillUnitSelect() {
  const options = ["<option value=\"\">Nao definido</option>"];
  for (const unit of state.units) {
    options.push(`<option value="${unit.id}">${unit.name}</option>`);
  }

  els.primaryUnitSelect.innerHTML = options.join("");
}

async function initialize() {
  state.units = (await api("/api/units")).units;
  fillUnitSelect();
  resetFormToNew();

  els.filterMonth.value = "";

  await refreshData();
}

function onTableClick(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const action = button.dataset.action;
  const billId = Number(button.dataset.id);

  if (action === "edit") {
    openEditDialog(billId).catch((error) => showToast(error.message, true));
    return;
  }

  if (action === "toggle-status") {
    toggleBillStatus(billId, button.dataset.status).catch((error) => showToast(error.message, true));
    return;
  }

  if (action === "delete") {
    deleteBill(billId).catch((error) => showToast(error.message, true));
    return;
  }

  if (action === "files") {
    openFilesDialog(billId).catch((error) => showToast(error.message, true));
  }
}

function onExistingFilesClick(event) {
  const button = event.target.closest("button[data-action='delete-existing-file']");
  if (!button) return;

  const fileId = Number(button.dataset.fileId);
  deleteExistingFile(fileId).catch((error) => showToast(error.message, true));
}

function setupEvents() {
  const refreshWithCatch = () => refreshData().catch((error) => showToast(error.message, true));

  const debouncedSearch = debounce((value) => {
    state.filters.q = value.trim();
    refreshWithCatch();
  }, 250);

  els.filterSearch.addEventListener("input", (event) => debouncedSearch(event.target.value));
  els.filterStatus.addEventListener("change", (event) => {
    state.filters.status = event.target.value;
    refreshWithCatch();
  });
  els.filterCategory.addEventListener("change", (event) => {
    state.filters.category = event.target.value;
    refreshWithCatch();
  });
  els.filterMonth.addEventListener("change", (event) => {
    state.filters.month = event.target.value;
    refreshWithCatch();
  });
  els.filterSort.addEventListener("change", (event) => {
    state.filters.sort = event.target.value;
    refreshWithCatch();
  });

  els.btnClearFilters.addEventListener("click", () => {
    state.filters = {
      q: "",
      status: "all",
      category: "all",
      month: "",
      sort: "due_asc",
    };

    els.filterSearch.value = "";
    els.filterStatus.value = "all";
    els.filterCategory.value = "all";
    els.filterMonth.value = "";
    els.filterSort.value = "due_asc";

    refreshWithCatch();
  });

  els.btnNew.addEventListener("click", openNewDialog);
  els.btnCloseDialog.addEventListener("click", closeBillDialog);
  els.btnCancelForm.addEventListener("click", closeBillDialog);
  els.billForm.addEventListener("submit", (event) => {
    submitBillForm(event).catch((error) => showToast(error.message, true));
  });

  els.sharedCheckbox.addEventListener("change", updateSplitModeUI);
  els.splitModeSelect.addEventListener("change", updateSplitModeUI);
  els.billForm.elements.total_amount.addEventListener("input", updateSplitModeUI);
  els.splitsBody.addEventListener("input", (event) => {
    if (event.target.classList.contains("split-amount")) {
      updateSplitModeUI();
    }
  });

  els.billsTbody.addEventListener("click", onTableClick);
  els.existingFilesList.addEventListener("click", onExistingFilesClick);

  els.btnExportCsv.addEventListener("click", () => {
    const params = new URLSearchParams();
    if (state.filters.q) params.set("q", state.filters.q);
    if (state.filters.status !== "all") params.set("status", state.filters.status);
    if (state.filters.category !== "all") params.set("category", state.filters.category);
    if (state.filters.month) params.set("month", state.filters.month);
    params.set("sort", state.filters.sort);

    window.location.href = `/api/export/csv?${params.toString()}`;
  });

  els.btnBackup.addEventListener("click", () => {
    window.location.href = "/api/backup";
  });

  els.btnCloseFiles.addEventListener("click", () => els.filesDialog.close());
}

setupEvents();
initialize().catch((error) => showToast(error.message, true));
