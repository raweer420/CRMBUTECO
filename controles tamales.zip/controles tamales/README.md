﻿# Controle de Contas do Terreno (Local)

Aplicativo local para organizar contas (luz, agua, internet, IPTU, gas etc.) com:

- Interface tipo planilha
- Banco SQLite local (`data/app.db`)
- Upload local de anexos PDF/JPG/PNG (`data/uploads/YYYY/MM`)
- Status da conta (`pending` / `paid`)
- Divisao por 4 unidades com modo igualitario ou custom
- Controle de pagamento individual por unidade (splits)
- Exportacao CSV
- Backup ZIP (`app.db + uploads`)

## Stack

- Backend: Node.js + Express
- Banco: SQLite (`better-sqlite3`)
- Frontend: HTML/CSS/JS puro

## Requisitos

- Node.js 18+ (recomendado 20+)
- Windows (tambem roda em Linux/Mac)

## Instalacao

No diretorio do projeto:

```bash
npm install
```

## Execucao

Modo desenvolvimento:

```bash
npm run dev
```

Modo normal:

```bash
npm start
```

Abra no navegador:

- `http://localhost:3000`

## Estrutura

```text
/server          # API Express + regras de negocio + SQLite
/public          # Frontend (HTML/CSS/JS)
/data
  app.db         # Banco local (criado automaticamente)
  /uploads       # Arquivos anexados
```

## Seed automatico

Na primeira execucao, o sistema cria automaticamente as 4 unidades em `units`:

1. Restaurante (Veganrole)
2. Studio (Tamales)
3. Minha casa (Matheus)
4. Casa do meu irmao (Augusto)

## Regras de divisao e arredondamento

- Quando `shared = true` e `split_mode = equal`, a API gera 4 splits automaticamente.
- Todos os valores usam 2 casas decimais.
- Centavos residuais ficam na primeira unidade para fechar exatamente o total.
- No modo `custom`, a soma dos 4 splits precisa bater exatamente com `total_amount`.

## Fluxo rapido de uso

1. Clique em `Nova conta`.
2. Preencha titulo, categoria, mes de referencia, vencimento e valor total.
3. Marque `Conta compartilhada` se quiser dividir entre os 4.
4. Escolha `Igual por 4` ou `Custom`.
5. Anexe boletos/arquivos (PDF/JPG/PNG).
6. Salve.
7. Na tabela principal, use filtros, edite, marque como pago/pendente e exclua quando necessario.

## Backup e CSV

- `Exportar CSV`: exporta as contas filtradas na tela.
- `Backup ZIP`: baixa um zip com `app.db` e pasta `uploads`.

## API REST (resumo)

- `GET /api/units`
- `GET /api/categories`
- `GET /api/bills`
- `GET /api/bills/:id`
- `POST /api/bills` (multipart: `payload` + `files[]`)
- `PUT /api/bills/:id` (multipart: `payload` + `files[]`)
- `DELETE /api/bills/:id`
- `GET /api/bills/:id/files`
- `DELETE /api/files/:id`
- `PUT /api/bills/:id/status`
- `PUT /api/bills/:billId/splits/:unitId/status`
- `GET /api/dashboard`
- `GET /api/export/csv`
- `GET /api/backup`

## Observacoes

- Tudo fica local no seu PC (sem dependencia de internet).
- Ao excluir uma conta, os registros relacionados (splits/anexos) sao removidos e os arquivos fisicos tambem.
- Tipos aceitos para upload: PDF, JPG/JPEG, PNG.
