﻿const path = require("path");

const CATEGORIES = ["luz", "agua", "internet", "iptu", "gas", "outros"];
const STATUS_VALUES = ["pending", "paid"];

function toCents(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) {
    throw new Error("Valor invalido.");
  }
  return Math.round(num * 100);
}

function fromCents(cents) {
  return Number((cents / 100).toFixed(2));
}

function normalizeMoney(value) {
  const cents = toCents(value);
  if (cents < 0) {
    throw new Error("Valor deve ser maior ou igual a zero.");
  }
  return fromCents(cents);
}

function validateMonth(value) {
  if (typeof value !== "string" || !/^\d{4}-(0[1-9]|1[0-2])$/.test(value)) {
    throw new Error("Mes de referencia deve estar no formato YYYY-MM.");
  }
  return value;
}

function validateDate(value) {
  if (typeof value !== "string" || !/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(value)) {
    throw new Error("Data deve estar no formato YYYY-MM-DD.");
  }
  return value;
}

function todayIsoDate() {
  return new Date().toISOString().slice(0, 10);
}

function sanitizeFilename(name) {
  return name.replace(/[^a-zA-Z0-9_.-]/g, "_");
}

function normalizeStoredPath(storedPath) {
  return storedPath.split(path.sep).join("/");
}

function computeEqualSplits(totalAmount, units) {
  const totalCents = toCents(totalAmount);
  const count = units.length;
  if (count === 0) {
    return [];
  }

  const base = Math.floor(totalCents / count);
  const remainder = totalCents - base * count;

  // Regra de arredondamento: centavos residuais vao para a primeira unidade.
  return units.map((unit, index) => {
    const cents = index === 0 ? base + remainder : base;
    return {
      unit_id: unit.id,
      amount: fromCents(cents),
      paid: 0,
      paid_at: null,
    };
  });
}

function normalizeStatus(status) {
  if (!STATUS_VALUES.includes(status)) {
    throw new Error("Status invalido.");
  }
  return status;
}

function normalizeCategory(category) {
  if (!CATEGORIES.includes(category)) {
    throw new Error("Categoria invalida.");
  }
  return category;
}

function ensureTitle(value) {
  const title = String(value || "").trim();
  if (!title) {
    throw new Error("Titulo e obrigatorio.");
  }
  return title;
}

function normalizeBoolean(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function parsePayload(rawPayload) {
  if (!rawPayload) {
    throw new Error("Payload ausente.");
  }

  if (typeof rawPayload === "object") {
    return rawPayload;
  }

  try {
    return JSON.parse(rawPayload);
  } catch (error) {
    throw new Error("Payload JSON invalido.");
  }
}

function normalizeCustomSplits(rawSplits, units, totalAmount) {
  if (!Array.isArray(rawSplits) || rawSplits.length !== units.length) {
    throw new Error("Divisao customizada deve ter valores para todas as unidades.");
  }

  const allowedIds = new Set(units.map((u) => u.id));
  const used = new Set();

  const normalized = rawSplits.map((split) => {
    const unitId = Number(split.unit_id);
    if (!allowedIds.has(unitId) || used.has(unitId)) {
      throw new Error("Unidade invalida na divisao customizada.");
    }
    used.add(unitId);

    const amount = normalizeMoney(split.amount);
    const paid = normalizeBoolean(split.paid) ? 1 : 0;
    const paidAt = paid ? validateDate(split.paid_at || todayIsoDate()) : null;

    return {
      unit_id: unitId,
      amount,
      paid,
      paid_at: paidAt,
    };
  });

  const sumCents = normalized.reduce((acc, split) => acc + toCents(split.amount), 0);
  const totalCents = toCents(totalAmount);
  if (sumCents !== totalCents) {
    throw new Error("A soma da divisao customizada deve ser igual ao valor total da conta.");
  }

  return normalized.sort((a, b) => a.unit_id - b.unit_id);
}

module.exports = {
  CATEGORIES,
  STATUS_VALUES,
  computeEqualSplits,
  ensureTitle,
  fromCents,
  normalizeBoolean,
  normalizeCategory,
  normalizeCustomSplits,
  normalizeDate: validateDate,
  normalizeMonth: validateMonth,
  normalizeMoney,
  normalizeStatus,
  normalizeStoredPath,
  parsePayload,
  sanitizeFilename,
  toCents,
  todayIsoDate,
};
