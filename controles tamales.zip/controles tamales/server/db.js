﻿const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

const DATA_DIR = path.join(__dirname, "..", "data");
const DB_PATH = path.join(DATA_DIR, "app.db");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

function ensureDirectories() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

function initDatabase() {
  ensureDirectories();

  const db = new Database(DB_PATH);
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS units (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS bills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      reference_month TEXT NOT NULL,
      due_date TEXT NOT NULL,
      total_amount REAL NOT NULL CHECK (total_amount >= 0),
      shared INTEGER NOT NULL DEFAULT 0,
      split_mode TEXT NOT NULL DEFAULT 'equal',
      primary_unit_id INTEGER,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      paid_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (primary_unit_id) REFERENCES units(id)
    );

    CREATE TABLE IF NOT EXISTS bill_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_id INTEGER NOT NULL,
      original_name TEXT NOT NULL,
      stored_path TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS bill_splits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_id INTEGER NOT NULL,
      unit_id INTEGER NOT NULL,
      amount REAL NOT NULL CHECK (amount >= 0),
      paid INTEGER NOT NULL DEFAULT 0,
      paid_at TEXT,
      FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
      FOREIGN KEY (unit_id) REFERENCES units(id),
      UNIQUE (bill_id, unit_id)
    );

    CREATE INDEX IF NOT EXISTS idx_bills_reference_month ON bills(reference_month);
    CREATE INDEX IF NOT EXISTS idx_bills_due_date ON bills(due_date);
    CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status);
    CREATE INDEX IF NOT EXISTS idx_bill_splits_bill_id ON bill_splits(bill_id);
    CREATE INDEX IF NOT EXISTS idx_bill_files_bill_id ON bill_files(bill_id);
  `);

  const seedUnits = db.prepare(`
    INSERT OR IGNORE INTO units (id, name) VALUES
      (1, 'Restaurante (Veganrole)'),
      (2, 'Studio (Tamales)'),
      (3, 'Minha casa (Matheus)'),
      (4, 'Casa do meu irmao (Augusto)')
  `);

  seedUnits.run();

  return db;
}

module.exports = {
  DATA_DIR,
  DB_PATH,
  UPLOADS_DIR,
  initDatabase,
};
