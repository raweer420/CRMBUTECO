﻿const express = require("express");
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const archiver = require("archiver");

const { DATA_DIR, DB_PATH, UPLOADS_DIR, initDatabase } = require("./db");
const {
  CATEGORIES,
  computeEqualSplits,
  ensureTitle,
  normalizeBoolean,
  normalizeCategory,
  normalizeCustomSplits,
  normalizeDate,
  normalizeMonth,
  normalizeMoney,
  normalizeStatus,
  normalizeStoredPath,
  parsePayload,
  sanitizeFilename,
  todayIsoDate,
  toCents,
} = require("./utils");

const app = express();
const db = initDatabase();
const PORT = Number(process.env.PORT || 3000);

const ALLOWED_MIME = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
]);

const ALLOWED_EXT = new Set([".pdf", ".jpg", ".jpeg", ".png"]);

function formatMoney(value) {
  return Number(Number(value || 0).toFixed(2));
}

function safeUnlink(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    console.error("Falha ao remover arquivo:", filePath, error.message);
  }
}

function cleanupUploadedFiles(files) {
  for (const file of files || []) {
    safeUnlink(file.path);
  }
}

function getUnits() {
  return db.prepare("SELECT id, name FROM units ORDER BY id").all();
}

function mapSplitsByBillIds(billIds) {
  if (!billIds.length) {
    return new Map();
  }

  const placeholders = billIds.map(() => "?").join(",");
  const rows = db
    .prepare(
      `
      SELECT
        bs.id,
        bs.bill_id,
        bs.unit_id,
        bs.amount,
        bs.paid,
        bs.paid_at,
        u.name AS unit_name
      FROM bill_splits bs
      JOIN units u ON u.id = bs.unit_id
      WHERE bs.bill_id IN (${placeholders})
      ORDER BY bs.bill_id, bs.unit_id
      `
    )
    .all(...billIds);

  const map = new Map();
  for (const row of rows) {
    const split = {
      id: row.id,
      bill_id: row.bill_id,
      unit_id: row.unit_id,
      unit_name: row.unit_name,
      amount: formatMoney(row.amount),
      paid: row.paid === 1,
      paid_at: row.paid_at,
    };

    if (!map.has(row.bill_id)) {
      map.set(row.bill_id, []);
    }
    map.get(row.bill_id).push(split);
  }

  return map;
}

function mapFileCountByBillIds(billIds) {
  if (!billIds.length) {
    return new Map();
  }

  const placeholders = billIds.map(() => "?").join(",");
  const rows = db
    .prepare(
      `
      SELECT bill_id, COUNT(*) AS total
      FROM bill_files
      WHERE bill_id IN (${placeholders})
      GROUP BY bill_id
      `
    )
    .all(...billIds);

  const map = new Map();
  for (const row of rows) {
    map.set(row.bill_id, row.total);
  }
  return map;
}

function serializeBill(row, splits, filesCount) {
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    reference_month: row.reference_month,
    due_date: row.due_date,
    total_amount: formatMoney(row.total_amount),
    shared: row.shared === 1,
    split_mode: row.split_mode,
    primary_unit_id: row.primary_unit_id,
    primary_unit_name: row.primary_unit_name || null,
    notes: row.notes || "",
    status: row.status,
    paid_at: row.paid_at,
    created_at: row.created_at,
    splits,
    files_count: filesCount,
  };
}

function parseSort(sortRaw) {
  switch (sortRaw) {
    case "due_desc":
      return "date(b.due_date) DESC, b.id DESC";
    case "created_desc":
      return "datetime(b.created_at) DESC, b.id DESC";
    default:
      return "date(b.due_date) ASC, b.id DESC";
  }
}

function buildBillListQuery(filters) {
  const where = [];
  const params = [];

  if (filters.q) {
    where.push("(b.title LIKE ? OR COALESCE(b.notes, '') LIKE ?)");
    params.push(`%${filters.q}%`, `%${filters.q}%`);
  }

  if (filters.status && filters.status !== "all") {
    where.push("b.status = ?");
    params.push(normalizeStatus(filters.status));
  }

  if (filters.category && filters.category !== "all") {
    where.push("b.category = ?");
    params.push(normalizeCategory(filters.category));
  }

  if (filters.month) {
    where.push("b.reference_month = ?");
    params.push(normalizeMonth(filters.month));
  }

  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const orderSql = parseSort(filters.sort);

  const sql = `
    SELECT
      b.*,
      u.name AS primary_unit_name
    FROM bills b
    LEFT JOIN units u ON u.id = b.primary_unit_id
    ${whereSql}
    ORDER BY ${orderSql}
  `;

  return { sql, params };
}

function buildNormalizedBill(payload, units) {
  const title = ensureTitle(payload.title);
  const category = normalizeCategory(payload.category);
  const referenceMonth = normalizeMonth(payload.reference_month);
  const dueDate = normalizeDate(payload.due_date);
  const totalAmount = normalizeMoney(payload.total_amount);
  const shared = normalizeBoolean(payload.shared);
  const notes = String(payload.notes || "").trim();

  const unitIds = new Set(units.map((unit) => unit.id));
  const primaryUnitId = payload.primary_unit_id ? Number(payload.primary_unit_id) : null;
  if (primaryUnitId !== null && !unitIds.has(primaryUnitId)) {
    throw new Error("Responsavel principal invalido.");
  }

  let splitMode = shared ? "equal" : "custom";
  if (shared) {
    splitMode = payload.split_mode === "custom" ? "custom" : "equal";
  }

  let splits = [];

  if (shared) {
    if (splitMode === "custom") {
      splits = normalizeCustomSplits(payload.splits, units, totalAmount);
    } else {
      const paidFlags = new Map();
      if (Array.isArray(payload.splits)) {
        for (const split of payload.splits) {
          const unitId = Number(split.unit_id);
          if (!unitIds.has(unitId)) {
            continue;
          }
          const paid = normalizeBoolean(split.paid) ? 1 : 0;
          const paidAt = paid ? normalizeDate(split.paid_at || todayIsoDate()) : null;
          paidFlags.set(unitId, { paid, paid_at: paidAt });
        }
      }

      splits = computeEqualSplits(totalAmount, units).map((split) => {
        const paidInfo = paidFlags.get(split.unit_id);
        if (!paidInfo) {
          return split;
        }
        return {
          ...split,
          paid: paidInfo.paid,
          paid_at: paidInfo.paid_at,
        };
      });
    }
  } else if (primaryUnitId) {
    splits = [
      {
        unit_id: primaryUnitId,
        amount: totalAmount,
        paid: 0,
        paid_at: null,
      },
    ];
  }

  let status = "pending";
  if (payload.status) {
    status = normalizeStatus(payload.status);
  } else if (splits.length > 0 && splits.every((split) => split.paid === 1)) {
    status = "paid";
  }

  let paidAt = null;
  if (status === "paid") {
    paidAt = payload.paid_at ? normalizeDate(payload.paid_at) : todayIsoDate();

    // Se a conta foi marcada como paga, replica o estado para os splits.
    splits = splits.map((split) => ({
      ...split,
      paid: 1,
      paid_at: split.paid_at || paidAt,
    }));
  }

  return {
    title,
    category,
    reference_month: referenceMonth,
    due_date: dueDate,
    total_amount: totalAmount,
    shared: shared ? 1 : 0,
    split_mode: splitMode,
    primary_unit_id: primaryUnitId,
    notes,
    status,
    paid_at: paidAt,
    splits,
  };
}

function serializeFile(fileRow) {
  return {
    id: fileRow.id,
    bill_id: fileRow.bill_id,
    original_name: fileRow.original_name,
    stored_path: fileRow.stored_path,
    mime_type: fileRow.mime_type,
    size_bytes: fileRow.size_bytes,
    uploaded_at: fileRow.uploaded_at,
    url: `/uploads/${encodeURI(fileRow.stored_path)}`,
  };
}

function generateCsv(rows) {
  const escapeCell = (value) => {
    const str = value === null || value === undefined ? "" : String(value);
    return `"${str.replaceAll('"', '""')}"`;
  };

  return rows.map((row) => row.map(escapeCell).join(",")).join("\n");
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const now = new Date();
    const year = String(now.getFullYear());
    const month = String(now.getMonth() + 1).padStart(2, "0");

    // Uploads ficam organizados localmente por ano/mes.
    const destination = path.join(UPLOADS_DIR, year, month);
    fs.mkdirSync(destination, { recursive: true });
    cb(null, destination);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const base = path.basename(file.originalname, ext);
    const safeBase = sanitizeFilename(base).slice(0, 60) || "arquivo";
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${safeBase}-${unique}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 20 * 1024 * 1024,
    files: 20,
  },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_MIME.has(file.mimetype) || !ALLOWED_EXT.has(ext)) {
      cb(new Error("Somente arquivos PDF/JPG/PNG sao permitidos."));
      return;
    }
    cb(null, true);
  },
});

const insertBillTx = db.transaction((bill, filesToInsert) => {
  const result = db
    .prepare(
      `
      INSERT INTO bills (
        title,
        category,
        reference_month,
        due_date,
        total_amount,
        shared,
        split_mode,
        primary_unit_id,
        notes,
        status,
        paid_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `
    )
    .run(
      bill.title,
      bill.category,
      bill.reference_month,
      bill.due_date,
      bill.total_amount,
      bill.shared,
      bill.split_mode,
      bill.primary_unit_id,
      bill.notes,
      bill.status,
      bill.paid_at
    );

  const billId = Number(result.lastInsertRowid);

  const splitStmt = db.prepare(
    `
    INSERT INTO bill_splits (bill_id, unit_id, amount, paid, paid_at)
    VALUES (?, ?, ?, ?, ?)
    `
  );

  for (const split of bill.splits) {
    splitStmt.run(billId, split.unit_id, split.amount, split.paid, split.paid_at);
  }

  const fileStmt = db.prepare(
    `
    INSERT INTO bill_files (
      bill_id,
      original_name,
      stored_path,
      mime_type,
      size_bytes
    ) VALUES (?, ?, ?, ?, ?)
    `
  );

  for (const file of filesToInsert) {
    fileStmt.run(
      billId,
      file.original_name,
      file.stored_path,
      file.mime_type,
      file.size_bytes
    );
  }

  return billId;
});

const updateBillTx = db.transaction((billId, bill, filesToInsert) => {
  db.prepare(
    `
    UPDATE bills
    SET
      title = ?,
      category = ?,
      reference_month = ?,
      due_date = ?,
      total_amount = ?,
      shared = ?,
      split_mode = ?,
      primary_unit_id = ?,
      notes = ?,
      status = ?,
      paid_at = ?
    WHERE id = ?
    `
  ).run(
    bill.title,
    bill.category,
    bill.reference_month,
    bill.due_date,
    bill.total_amount,
    bill.shared,
    bill.split_mode,
    bill.primary_unit_id,
    bill.notes,
    bill.status,
    bill.paid_at,
    billId
  );

  db.prepare("DELETE FROM bill_splits WHERE bill_id = ?").run(billId);

  const splitStmt = db.prepare(
    `
    INSERT INTO bill_splits (bill_id, unit_id, amount, paid, paid_at)
    VALUES (?, ?, ?, ?, ?)
    `
  );

  for (const split of bill.splits) {
    splitStmt.run(billId, split.unit_id, split.amount, split.paid, split.paid_at);
  }

  const fileStmt = db.prepare(
    `
    INSERT INTO bill_files (
      bill_id,
      original_name,
      stored_path,
      mime_type,
      size_bytes
    ) VALUES (?, ?, ?, ?, ?)
    `
  );

  for (const file of filesToInsert) {
    fileStmt.run(
      billId,
      file.original_name,
      file.stored_path,
      file.mime_type,
      file.size_bytes
    );
  }
});

const deleteBillTx = db.transaction((billId) => {
  const files = db
    .prepare("SELECT id, stored_path FROM bill_files WHERE bill_id = ?")
    .all(billId);

  db.prepare("DELETE FROM bills WHERE id = ?").run(billId);
  return files;
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

app.use("/uploads", express.static(UPLOADS_DIR));
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/api/units", (req, res) => {
  res.json({ units: getUnits() });
});

app.get("/api/categories", (req, res) => {
  res.json({ categories: CATEGORIES });
});

app.get("/api/bills", (req, res, next) => {
  try {
    const filters = {
      q: String(req.query.q || "").trim(),
      status: String(req.query.status || "all"),
      category: String(req.query.category || "all"),
      month: String(req.query.month || "").trim(),
      sort: String(req.query.sort || "due_asc"),
    };

    const { sql, params } = buildBillListQuery(filters);
    const billRows = db.prepare(sql).all(...params);
    const billIds = billRows.map((bill) => bill.id);
    const splitMap = mapSplitsByBillIds(billIds);
    const fileCountMap = mapFileCountByBillIds(billIds);

    const bills = billRows.map((row) =>
      serializeBill(row, splitMap.get(row.id) || [], fileCountMap.get(row.id) || 0)
    );

    res.json({ bills });
  } catch (error) {
    next(error);
  }
});

app.get("/api/bills/:id", (req, res, next) => {
  try {
    const billId = Number(req.params.id);
    if (!Number.isInteger(billId) || billId <= 0) {
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const billRow = db
      .prepare(
        `
        SELECT b.*, u.name AS primary_unit_name
        FROM bills b
        LEFT JOIN units u ON u.id = b.primary_unit_id
        WHERE b.id = ?
        `
      )
      .get(billId);

    if (!billRow) {
      res.status(404).json({ error: "Conta nao encontrada." });
      return;
    }

    const splits = mapSplitsByBillIds([billId]).get(billId) || [];
    const files = db
      .prepare(
        `
        SELECT id, bill_id, original_name, stored_path, mime_type, size_bytes, uploaded_at
        FROM bill_files
        WHERE bill_id = ?
        ORDER BY uploaded_at ASC
        `
      )
      .all(billId)
      .map(serializeFile);

    const bill = serializeBill(billRow, splits, files.length);
    bill.files = files;

    res.json({ bill });
  } catch (error) {
    next(error);
  }
});

app.get("/api/bills/:id/files", (req, res, next) => {
  try {
    const billId = Number(req.params.id);
    if (!Number.isInteger(billId) || billId <= 0) {
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const files = db
      .prepare(
        `
        SELECT id, bill_id, original_name, stored_path, mime_type, size_bytes, uploaded_at
        FROM bill_files
        WHERE bill_id = ?
        ORDER BY uploaded_at ASC
        `
      )
      .all(billId)
      .map(serializeFile);

    res.json({ files });
  } catch (error) {
    next(error);
  }
});

app.post("/api/bills", upload.array("files", 20), (req, res, next) => {
  const uploadedFiles = req.files || [];

  try {
    const payload = parsePayload(req.body.payload);
    const units = getUnits();
    const bill = buildNormalizedBill(payload, units);

    const filesToInsert = uploadedFiles.map((file) => ({
      original_name: file.originalname,
      stored_path: normalizeStoredPath(path.relative(UPLOADS_DIR, file.path)),
      mime_type: file.mimetype,
      size_bytes: file.size,
    }));

    const billId = insertBillTx(bill, filesToInsert);
    res.status(201).json({ id: billId });
  } catch (error) {
    cleanupUploadedFiles(uploadedFiles);
    next(error);
  }
});

app.put("/api/bills/:id", upload.array("files", 20), (req, res, next) => {
  const billId = Number(req.params.id);
  const uploadedFiles = req.files || [];

  try {
    if (!Number.isInteger(billId) || billId <= 0) {
      cleanupUploadedFiles(uploadedFiles);
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const exists = db.prepare("SELECT id FROM bills WHERE id = ?").get(billId);
    if (!exists) {
      cleanupUploadedFiles(uploadedFiles);
      res.status(404).json({ error: "Conta nao encontrada." });
      return;
    }

    const payload = parsePayload(req.body.payload);
    const units = getUnits();
    const bill = buildNormalizedBill(payload, units);

    const filesToInsert = uploadedFiles.map((file) => ({
      original_name: file.originalname,
      stored_path: normalizeStoredPath(path.relative(UPLOADS_DIR, file.path)),
      mime_type: file.mimetype,
      size_bytes: file.size,
    }));

    updateBillTx(billId, bill, filesToInsert);
    res.json({ ok: true });
  } catch (error) {
    cleanupUploadedFiles(uploadedFiles);
    next(error);
  }
});

app.delete("/api/bills/:id", (req, res, next) => {
  try {
    const billId = Number(req.params.id);
    if (!Number.isInteger(billId) || billId <= 0) {
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const bill = db.prepare("SELECT id FROM bills WHERE id = ?").get(billId);
    if (!bill) {
      res.status(404).json({ error: "Conta nao encontrada." });
      return;
    }

    const files = deleteBillTx(billId);
    for (const file of files) {
      const fullPath = path.join(UPLOADS_DIR, file.stored_path);
      safeUnlink(fullPath);
    }

    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.delete("/api/files/:id", (req, res, next) => {
  try {
    const fileId = Number(req.params.id);
    if (!Number.isInteger(fileId) || fileId <= 0) {
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const file = db
      .prepare(
        `
        SELECT id, stored_path
        FROM bill_files
        WHERE id = ?
        `
      )
      .get(fileId);

    if (!file) {
      res.status(404).json({ error: "Arquivo nao encontrado." });
      return;
    }

    db.prepare("DELETE FROM bill_files WHERE id = ?").run(fileId);
    safeUnlink(path.join(UPLOADS_DIR, file.stored_path));

    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.put("/api/bills/:id/status", (req, res, next) => {
  try {
    const billId = Number(req.params.id);
    if (!Number.isInteger(billId) || billId <= 0) {
      res.status(400).json({ error: "ID invalido." });
      return;
    }

    const status = normalizeStatus(req.body.status);
    const paidAt = status === "paid" ? todayIsoDate() : null;

    const tx = db.transaction(() => {
      const info = db
        .prepare(
          `
          UPDATE bills
          SET status = ?, paid_at = ?
          WHERE id = ?
          `
        )
        .run(status, paidAt, billId);

      if (info.changes === 0) {
        throw new Error("Conta nao encontrada.");
      }

      if (status === "paid") {
        db.prepare(
          `
          UPDATE bill_splits
          SET paid = 1, paid_at = COALESCE(paid_at, ?)
          WHERE bill_id = ?
          `
        ).run(paidAt, billId);
      } else {
        db.prepare(
          `
          UPDATE bill_splits
          SET paid = 0, paid_at = NULL
          WHERE bill_id = ?
          `
        ).run(billId);
      }
    });

    tx();
    res.json({ ok: true, status, paid_at: paidAt });
  } catch (error) {
    if (error.message === "Conta nao encontrada.") {
      res.status(404).json({ error: error.message });
      return;
    }
    next(error);
  }
});

app.put("/api/bills/:billId/splits/:unitId/status", (req, res, next) => {
  try {
    const billId = Number(req.params.billId);
    const unitId = Number(req.params.unitId);
    const paid = normalizeBoolean(req.body.paid);

    if (!Number.isInteger(billId) || billId <= 0 || !Number.isInteger(unitId) || unitId <= 0) {
      res.status(400).json({ error: "Parametro invalido." });
      return;
    }

    const paidAt = paid ? todayIsoDate() : null;

    const tx = db.transaction(() => {
      const info = db
        .prepare(
          `
          UPDATE bill_splits
          SET paid = ?, paid_at = ?
          WHERE bill_id = ? AND unit_id = ?
          `
        )
        .run(paid ? 1 : 0, paidAt, billId, unitId);

      if (info.changes === 0) {
        throw new Error("Split nao encontrado.");
      }

      const summary = db
        .prepare(
          `
          SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN paid = 1 THEN 1 ELSE 0 END) AS paid_count
          FROM bill_splits
          WHERE bill_id = ?
          `
        )
        .get(billId);

      if (summary.total > 0 && summary.paid_count === summary.total) {
        db.prepare("UPDATE bills SET status = 'paid', paid_at = ? WHERE id = ?").run(todayIsoDate(), billId);
      } else {
        db.prepare("UPDATE bills SET status = 'pending', paid_at = NULL WHERE id = ?").run(billId);
      }
    });

    tx();
    res.json({ ok: true });
  } catch (error) {
    if (error.message === "Split nao encontrado.") {
      res.status(404).json({ error: error.message });
      return;
    }
    next(error);
  }
});

app.get("/api/dashboard", (req, res, next) => {
  try {
    const month = req.query.month
      ? normalizeMonth(String(req.query.month))
      : new Date().toISOString().slice(0, 7);

    const pending = db
      .prepare("SELECT COALESCE(SUM(total_amount), 0) AS total FROM bills WHERE status = 'pending'")
      .get().total;
    const paid = db
      .prepare("SELECT COALESCE(SUM(total_amount), 0) AS total FROM bills WHERE status = 'paid'")
      .get().total;
    const monthTotal = db
      .prepare("SELECT COALESCE(SUM(total_amount), 0) AS total FROM bills WHERE reference_month = ?")
      .get(month).total;

    const perUnit = db
      .prepare(
        `
        SELECT
          u.id,
          u.name,
          COALESCE(SUM(CASE WHEN b.reference_month = ? THEN bs.amount ELSE 0 END), 0) AS total_amount,
          COALESCE(SUM(CASE WHEN b.reference_month = ? AND bs.paid = 0 THEN bs.amount ELSE 0 END), 0) AS pending_amount
        FROM units u
        LEFT JOIN bill_splits bs ON bs.unit_id = u.id
        LEFT JOIN bills b ON b.id = bs.bill_id
        GROUP BY u.id, u.name
        ORDER BY u.id
        `
      )
      .all(month, month)
      .map((row) => ({
        id: row.id,
        name: row.name,
        total_amount: formatMoney(row.total_amount),
        pending_amount: formatMoney(row.pending_amount),
      }));

    res.json({
      selected_month: month,
      total_pending: formatMoney(pending),
      total_paid: formatMoney(paid),
      total_month: formatMoney(monthTotal),
      per_unit: perUnit,
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/export/csv", (req, res, next) => {
  try {
    const filters = {
      q: String(req.query.q || "").trim(),
      status: String(req.query.status || "all"),
      category: String(req.query.category || "all"),
      month: String(req.query.month || "").trim(),
      sort: String(req.query.sort || "due_asc"),
    };

    const { sql, params } = buildBillListQuery(filters);
    const billRows = db.prepare(sql).all(...params);
    const billIds = billRows.map((bill) => bill.id);
    const splitMap = mapSplitsByBillIds(billIds);

    const rows = [
      [
        "ID",
        "Titulo",
        "Categoria",
        "Mes Ref",
        "Vencimento",
        "Valor Total",
        "Compartilhada",
        "Divisao",
        "Responsavel Principal",
        "Status",
        "Pago em",
        "Notas",
      ],
    ];

    for (const bill of billRows) {
      const splits = splitMap.get(bill.id) || [];
      const splitSummary = splits
        .map((split) => `${split.unit_name}: ${split.amount.toFixed(2)} (${split.paid ? "pago" : "pendente"})`)
        .join(" | ");

      rows.push([
        bill.id,
        bill.title,
        bill.category,
        bill.reference_month,
        bill.due_date,
        formatMoney(bill.total_amount).toFixed(2),
        bill.shared === 1 ? "sim" : "nao",
        bill.shared === 1 ? `${bill.split_mode} | ${splitSummary}` : "nao compartilhada",
        bill.primary_unit_name || "",
        bill.status,
        bill.paid_at || "",
        bill.notes || "",
      ]);
    }

    const csv = generateCsv(rows);
    const monthSuffix = filters.month || "todos";

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="contas-${monthSuffix}.csv"`);
    res.send(`\uFEFF${csv}`);
  } catch (error) {
    next(error);
  }
});

app.get("/api/backup", (req, res, next) => {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });

    const stamp = todayIsoDate().replaceAll("-", "");
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="backup-contas-${stamp}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", (error) => next(error));
    archive.pipe(res);

    archive.file(DB_PATH, { name: "app.db" });
    if (fs.existsSync(UPLOADS_DIR)) {
      archive.directory(UPLOADS_DIR, "uploads");
    }

    archive.finalize();
  } catch (error) {
    next(error);
  }
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.use((error, req, res, next) => {
  console.error(error);

  if (error instanceof multer.MulterError) {
    res.status(400).json({ error: error.message });
    return;
  }

  if (error.message) {
    res.status(400).json({ error: error.message });
    return;
  }

  res.status(500).json({ error: "Erro interno do servidor." });
});

app.listen(PORT, () => {
  console.log(`Servidor iniciado em http://localhost:${PORT}`);
});
